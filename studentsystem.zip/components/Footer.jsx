function Footer() {
  return (
    <div className="py-[20px] text-[18px] text-center text-white">
      © By Bunyad Mirzazada 2023
    </div>
  );
}
export default Footer;
