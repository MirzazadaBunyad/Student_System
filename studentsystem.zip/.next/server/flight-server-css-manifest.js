self.__RSC_CSS_MANIFEST={
  "__entry_css_mods__": {
    "E:\\lesson-nextjs13-studentsystem-main\\app\\students\\[department]\\[studentId]\\page": [
      "E:\\lesson-nextjs13-studentsystem-main\\app\\globals.css"
    ],
    "E:\\lesson-nextjs13-studentsystem-main\\app\\new-student\\page": [
      "E:\\lesson-nextjs13-studentsystem-main\\app\\globals.css"
    ],
    "E:\\lesson-nextjs13-studentsystem-main\\app\\students\\page": [
      "E:\\lesson-nextjs13-studentsystem-main\\app\\globals.css"
    ]
  },
  "E:\\lesson-nextjs13-studentsystem-main\\app\\layout.jsx": [
    "E:\\lesson-nextjs13-studentsystem-main\\app\\globals.css"
  ]
}