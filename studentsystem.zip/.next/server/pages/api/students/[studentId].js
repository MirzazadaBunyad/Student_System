"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/students/[studentId]";
exports.ids = ["pages/api/students/[studentId]"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./config/db.js":
/*!**********************!*\
  !*** ./config/db.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"dbConnect\": () => (/* binding */ dbConnect)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst MONGO_URI = \"mongodb+srv://testuser1:Mirzazada.2023@cluster0.3a0ztbu.mongodb.net/\";\nconst dbConnect = async ()=>{\n    try {\n        await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGO_URI);\n        console.log(\"Database connected\");\n    } catch (error) {\n        console.log(error);\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9jb25maWcvZGIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWdDO0FBQ2hDLE1BQU1DLFlBQVk7QUFDWCxNQUFNQyxZQUFZLFVBQVk7SUFDbkMsSUFBSTtRQUNGLE1BQU1GLHVEQUFnQixDQUFDQztRQUV2QkcsUUFBUUMsR0FBRyxDQUFDO0lBQ2QsRUFBRSxPQUFPQyxPQUFPO1FBQ2RGLFFBQVFDLEdBQUcsQ0FBQ0M7SUFDZDtBQUNGLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zdHVkZW50YXBwLy4vY29uZmlnL2RiLmpzP2I0OTMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xuY29uc3QgTU9OR09fVVJJID0gJ21vbmdvZGIrc3J2Oi8vdGVzdHVzZXIxOk1pcnphemFkYS4yMDIzQGNsdXN0ZXIwLjNhMHp0YnUubW9uZ29kYi5uZXQvJ1xuZXhwb3J0IGNvbnN0IGRiQ29ubmVjdCA9IGFzeW5jICgpID0+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KE1PTkdPX1VSSSk7XG5cbiAgICBjb25zb2xlLmxvZyhcIkRhdGFiYXNlIGNvbm5lY3RlZFwiKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gIH1cbn07XG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJNT05HT19VUkkiLCJkYkNvbm5lY3QiLCJjb25uZWN0IiwiY29uc29sZSIsImxvZyIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./config/db.js\n");

/***/ }),

/***/ "(api)/./models/studentModel.js":
/*!********************************!*\
  !*** ./models/studentModel.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst studentSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    fullname: {\n        type: String,\n        required: true\n    },\n    mobile: {\n        type: String,\n        required: true\n    },\n    email: {\n        type: String,\n        required: true\n    },\n    department: {\n        type: String,\n        required: true\n    },\n    address: {\n        type: String,\n        required: true\n    },\n    image: {\n        type: String,\n        required: true\n    }\n}, {\n    timestamps: true\n});\n(mongoose__WEBPACK_IMPORTED_MODULE_0___default().models) = {};\nconst Student = mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"Student\", studentSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Student);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvc3R1ZGVudE1vZGVsLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUVoQyxNQUFNQyxnQkFBZ0IsSUFBSUQsd0RBQWUsQ0FDdkM7SUFDRUcsVUFBVTtRQUNSQyxNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFFaEI7SUFDQUMsUUFBUTtRQUNOSCxNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFFaEI7SUFDQUUsT0FBTztRQUNMSixNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFFaEI7SUFDQUcsWUFBWTtRQUNWTCxNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFDaEI7SUFDQUksU0FBUztRQUNQTixNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFFaEI7SUFDQUssT0FBTztRQUNMUCxNQUFNQztRQUNOQyxVQUFVLElBQUk7SUFFaEI7QUFDRixHQUNBO0lBQUVNLFlBQVksSUFBSTtBQUFDO0FBR3JCWix3REFBZSxHQUFHLENBQUM7QUFFbkIsTUFBTWMsVUFBVWQscURBQWMsQ0FBQyxXQUFXQztBQUUxQyxpRUFBZWEsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3N0dWRlbnRhcHAvLi9tb2RlbHMvc3R1ZGVudE1vZGVsLmpzP2ZiODciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xuXG5jb25zdCBzdHVkZW50U2NoZW1hID0gbmV3IG1vbmdvb3NlLlNjaGVtYShcbiAge1xuICAgIGZ1bGxuYW1lOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgIC8vIG1heExlbmd0aDogMjAsXG4gICAgfSxcbiAgICBtb2JpbGU6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgLy8gbWF4TGVuZ3RoOiAyMCxcbiAgICB9LFxuICAgIGVtYWlsOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgIC8vIG1heExlbmd0aDogMjAsXG4gICAgfSxcbiAgICBkZXBhcnRtZW50OiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICB9LFxuICAgIGFkZHJlc3M6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgICAgLy8gbWF4TGVuZ3RoOiAyMCxcbiAgICB9LFxuICAgIGltYWdlOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgIC8vIG1heExlbmd0aDogMjAwLFxuICAgIH0sXG4gIH0sXG4gIHsgdGltZXN0YW1wczogdHJ1ZSB9XG4pO1xuXG5tb25nb29zZS5tb2RlbHMgPSB7fTtcblxuY29uc3QgU3R1ZGVudCA9IG1vbmdvb3NlLm1vZGVsKFwiU3R1ZGVudFwiLCBzdHVkZW50U2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgU3R1ZGVudDtcbiJdLCJuYW1lcyI6WyJtb25nb29zZSIsInN0dWRlbnRTY2hlbWEiLCJTY2hlbWEiLCJmdWxsbmFtZSIsInR5cGUiLCJTdHJpbmciLCJyZXF1aXJlZCIsIm1vYmlsZSIsImVtYWlsIiwiZGVwYXJ0bWVudCIsImFkZHJlc3MiLCJpbWFnZSIsInRpbWVzdGFtcHMiLCJtb2RlbHMiLCJTdHVkZW50IiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/studentModel.js\n");

/***/ }),

/***/ "(api)/./pages/api/students/[studentId].js":
/*!*******************************************!*\
  !*** ./pages/api/students/[studentId].js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _models_studentModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/models/studentModel */ \"(api)/./models/studentModel.js\");\n/* harmony import */ var _config_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/config/db */ \"(api)/./config/db.js\");\n\n\n\n(0,_config_db__WEBPACK_IMPORTED_MODULE_2__.dbConnect)();\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    const { studentId  } = req.query;\n    const { method  } = req;\n    switch(method){\n        case \"GET\":\n            try {\n                const student = await _models_studentModel__WEBPACK_IMPORTED_MODULE_1__[\"default\"].findById(studentId);\n                res.status(200).json({\n                    success: true,\n                    data: student\n                });\n            } catch (error) {\n                res.status(400).json({\n                    success: false,\n                    message: error\n                });\n            }\n            break;\n        case \"PUT\":\n            try {\n                const student = await _models_studentModel__WEBPACK_IMPORTED_MODULE_1__[\"default\"].findByIdAndUpdate({\n                    _id: studentId\n                }, {\n                    ...req.body\n                });\n                res.status(200).json({\n                    success: true,\n                    data: student\n                });\n            } catch (error) {\n                res.status(400).json({\n                    success: false,\n                    message: error\n                });\n            }\n            break;\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvc3R1ZGVudHMvW3N0dWRlbnRJZF0uanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBZ0M7QUFDWTtBQUNKO0FBRXhDRSxxREFBU0E7QUFFVCxpRUFBZSxPQUFPQyxLQUFLQyxNQUFRO0lBQ2pDLE1BQU0sRUFBRUMsVUFBUyxFQUFFLEdBQUdGLElBQUlHLEtBQUs7SUFDL0IsTUFBTSxFQUFFQyxPQUFNLEVBQUUsR0FBR0o7SUFFbkIsT0FBUUk7UUFDTixLQUFLO1lBQ0gsSUFBSTtnQkFDRixNQUFNQyxVQUFVLE1BQU1QLHFFQUFnQixDQUFDSTtnQkFFdkNELElBQUlNLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7b0JBQUVDLFNBQVMsSUFBSTtvQkFBRUMsTUFBTUw7Z0JBQVE7WUFDdEQsRUFBRSxPQUFPTSxPQUFPO2dCQUNkVixJQUFJTSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUFFQyxTQUFTLEtBQUs7b0JBQUVHLFNBQVNEO2dCQUFNO1lBQ3hEO1lBQ0EsS0FBTTtRQUNSLEtBQUs7WUFDSCxJQUFJO2dCQUNGLE1BQU1OLFVBQVUsTUFBTVAsOEVBQXlCLENBQzdDO29CQUFFZ0IsS0FBS1o7Z0JBQVUsR0FDakI7b0JBQUUsR0FBR0YsSUFBSWUsSUFBSTtnQkFBQztnQkFFaEJkLElBQUlNLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7b0JBQUVDLFNBQVMsSUFBSTtvQkFBRUMsTUFBTUw7Z0JBQVE7WUFDdEQsRUFBRSxPQUFPTSxPQUFPO2dCQUNkVixJQUFJTSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUFFQyxTQUFTLEtBQUs7b0JBQUVHLFNBQVNEO2dCQUFNO1lBQ3hEO1lBQ0EsS0FBTTtJQUNWO0FBQ0YsR0FBRSIsInNvdXJjZXMiOlsid2VicGFjazovL3N0dWRlbnRhcHAvLi9wYWdlcy9hcGkvc3R1ZGVudHMvW3N0dWRlbnRJZF0uanM/MTVlYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSBcIm1vbmdvb3NlXCI7XG5pbXBvcnQgU3R1ZGVudCBmcm9tIFwiQC9tb2RlbHMvc3R1ZGVudE1vZGVsXCI7XG5pbXBvcnQgeyBkYkNvbm5lY3QgfSBmcm9tIFwiQC9jb25maWcvZGJcIjtcblxuZGJDb25uZWN0KCk7XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXEsIHJlcykgPT4ge1xuICBjb25zdCB7IHN0dWRlbnRJZCB9ID0gcmVxLnF1ZXJ5O1xuICBjb25zdCB7IG1ldGhvZCB9ID0gcmVxO1xuXG4gIHN3aXRjaCAobWV0aG9kKSB7XG4gICAgY2FzZSBcIkdFVFwiOlxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc3R1ZGVudCA9IGF3YWl0IFN0dWRlbnQuZmluZEJ5SWQoc3R1ZGVudElkKTtcblxuICAgICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHN0dWRlbnQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXMuc3RhdHVzKDQwMCkuanNvbih7IHN1Y2Nlc3M6IGZhbHNlLCBtZXNzYWdlOiBlcnJvciB9KTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJQVVRcIjpcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0dWRlbnQgPSBhd2FpdCBTdHVkZW50LmZpbmRCeUlkQW5kVXBkYXRlKFxuICAgICAgICAgIHsgX2lkOiBzdHVkZW50SWQgfSxcbiAgICAgICAgICB7IC4uLnJlcS5ib2R5IH1cbiAgICAgICAgKTtcbiAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBzdHVkZW50IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVzLnN0YXR1cyg0MDApLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogZXJyb3IgfSk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgfVxufTtcbiJdLCJuYW1lcyI6WyJtb25nb29zZSIsIlN0dWRlbnQiLCJkYkNvbm5lY3QiLCJyZXEiLCJyZXMiLCJzdHVkZW50SWQiLCJxdWVyeSIsIm1ldGhvZCIsInN0dWRlbnQiLCJmaW5kQnlJZCIsInN0YXR1cyIsImpzb24iLCJzdWNjZXNzIiwiZGF0YSIsImVycm9yIiwibWVzc2FnZSIsImZpbmRCeUlkQW5kVXBkYXRlIiwiX2lkIiwiYm9keSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/students/[studentId].js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/students/[studentId].js"));
module.exports = __webpack_exports__;

})();