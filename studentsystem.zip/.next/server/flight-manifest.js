self.__RSC_MANIFEST={
  "__ssr_module_mapping__": {
    "(app-client)/./components/StudentList.jsx": {
      "": {
        "id": "(sc_client)/./components/StudentList.jsx",
        "name": "",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/StudentList.jsx",
        "name": "*",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/StudentList.jsx",
        "name": "default",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/link.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "*",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "default",
        "chunks": [
          "app/students/[department]/page:app/students/[department]/page"
        ],
        "async": false
      }
    },
    "(app-client)/./components/Sidebar.jsx": {
      "": {
        "id": "(sc_client)/./components/Sidebar.jsx",
        "name": "",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/Sidebar.jsx",
        "name": "*",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/Sidebar.jsx",
        "name": "default",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./components/EditForm.jsx": {
      "": {
        "id": "(sc_client)/./components/EditForm.jsx",
        "name": "",
        "chunks": [
          "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/EditForm.jsx",
        "name": "*",
        "chunks": [
          "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/EditForm.jsx",
        "name": "default",
        "chunks": [
          "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
        ],
        "async": false
      }
    },
    "(app-client)/./components/Form.jsx": {
      "": {
        "id": "(sc_client)/./components/Form.jsx",
        "name": "",
        "chunks": [
          "app/new-student/page:app/new-student/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/Form.jsx",
        "name": "*",
        "chunks": [
          "app/new-student/page:app/new-student/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/Form.jsx",
        "name": "default",
        "chunks": [
          "app/new-student/page:app/new-student/page"
        ],
        "async": false
      }
    }
  },
  "__edge_ssr_module_mapping__": {},
  "__entry_css_files__": {
    "E:\\lesson-nextjs13-studentsystem-main\\app\\layout": [
      "static/css/_app-client_app_globals_css.css"
    ]
  },
  "E:\\lesson-nextjs13-studentsystem-main\\components\\StudentList.jsx": {
    "": {
      "id": "(app-client)/./components/StudentList.jsx",
      "name": "",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/StudentList.jsx",
      "name": "*",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/StudentList.jsx",
      "name": "default",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\node_modules\\next\\dist\\client\\link.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "*",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "default",
      "chunks": [
        "app/students/[department]/page:app/students/[department]/page"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\components\\Sidebar.jsx": {
    "": {
      "id": "(app-client)/./components/Sidebar.jsx",
      "name": "",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/Sidebar.jsx",
      "name": "*",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/Sidebar.jsx",
      "name": "default",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\node_modules\\next\\dist\\client\\components\\app-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\components\\EditForm.jsx": {
    "": {
      "id": "(app-client)/./components/EditForm.jsx",
      "name": "",
      "chunks": [
        "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/EditForm.jsx",
      "name": "*",
      "chunks": [
        "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/EditForm.jsx",
      "name": "default",
      "chunks": [
        "app/students/[department]/[studentId]/page:app/students/[department]/[studentId]/page"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\components\\Form.jsx": {
    "": {
      "id": "(app-client)/./components/Form.jsx",
      "name": "",
      "chunks": [
        "app/new-student/page:app/new-student/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/Form.jsx",
      "name": "*",
      "chunks": [
        "app/new-student/page:app/new-student/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/Form.jsx",
      "name": "default",
      "chunks": [
        "app/new-student/page:app/new-student/page"
      ],
      "async": false
    }
  },
  "E:\\lesson-nextjs13-studentsystem-main\\app\\globals.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/_app-client_app_globals_css.css"
      ]
    }
  }
}