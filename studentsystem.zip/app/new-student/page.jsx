import Form from '@/components/Form'
import React from 'react'

export default function NewStudent() {
  return (
    <Form   />
  )
}
